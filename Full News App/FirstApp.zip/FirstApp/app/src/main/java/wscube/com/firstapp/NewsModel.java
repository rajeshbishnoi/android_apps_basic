package wscube.com.firstapp;

import java.io.Serializable;

/**
 * Created by wscube on 2/1/17.
 */

public class NewsModel implements Serializable {
    String title, description, date, url;

    public String getTitle() {
        return title;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
